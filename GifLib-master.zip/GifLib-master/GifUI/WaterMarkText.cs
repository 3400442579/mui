﻿//======================================================================
//
//        Copyright (C) 2007-2008 Jillzhang
//        All rights reserved
//        guid1:  d39bc079-1093-43b1-ac63-8b934f2cd2b4
//        guid2:  4368d84d-43a0-4ea2-954c-eac2beecaa63
//        guid3:  77ba0f30-deb0-4ddf-a437-e4cc9d75b1f1
//        guid4:  3f7f2269-5543-4a5d-9355-256709e4a981
//        guid5:  bc705bac-dfa1-44a0-8398-5436dbfa82d2
//        CLR版本:            2.0.50727.1433
//        新建项输入的名称: Class1
//        机器名称:            JILLZHANG-PC
//        注册组织名:         
//        命名空间名称:      GifUI
//        文件名:              Class1
//        当前系统时间:      4/12/2008 1:52:36 PM
//        用户所在的域:      jillzhang-PC
//        当前登录用户名:   jillzhang
//        创建年份:           2008
//
//        created by Jillzhang at  4/12/2008 1:52:36 PM
//        http://jillzhang.cnblogs.com
//
//======================================================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace GifUI
{
    public class WaterMarkText
    {
        public string Text;
        public Font Font;
        public Color ForceColor = Color.Black;
    }
}
